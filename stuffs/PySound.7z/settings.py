import pygame as pg 
pg.font.init()

# Define colors (R, G, B)
BG = (17, 18, 20)
TEXT_COLOR = (226, 227, 230)

# Define sounds
AUDIO1 = "TinhNguDiEmOi"
AUDIO2 = "vine-boom"
AUDIO3 = "yamate"
AUDIO4 = "monkey"
AUDIO5 = "OMG"
AUDIO6 = "siuuu"
AUDIO7 = "ai-o-si-ma"
AUDIO8 = "ngu"
AUDIO9 = "an3tocom"

# Define system variables
TITLE = "Python Soundboard"
WIDTH = 800
HEIGHT = 600
FPS = 60

AUDIO_FORMAT = ".wav"
AUDIO_FORMAT_2 = ".ogg"

# Define images
ELEMENTS_IMG = 'elements.png'
MOYAI_IMG = 'moyai.png'
SIUUU_IMG = "siuuu.png"

# Define font
FONTFILE = "Anton.ttf"
EMOJIFONTFILE = "Noto.ttf"