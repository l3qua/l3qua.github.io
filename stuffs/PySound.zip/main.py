import pygame as pg
from os import path
import sys
import soundfile as sf
from settings import *
from sprites import *

class App:
    def __init__(self):
        pg.init()
        pg.mixer.init()
        pg.font.init()
        
        icon = pg.image.load('./assets/images/icon.png')
        pg.display.set_icon(icon)
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.elements_pixels_x = 227
        self.elements_pixels_y = 61
        self.sound_playing = False

    def load_data(self):
        game_folder = path.dirname(__file__)
        assets_folder = path.join(game_folder, 'assets')
        img_folder = path.join(assets_folder, 'images')
        snd_folder = path.join(assets_folder, 'sounds')
        font_folder = path.join(assets_folder, 'fonts')

        # Define fonts
        self.font = pg.font.Font(path.join(font_folder, FONTFILE), 28)
        
        # Define images
        self.elements_img = pg.image.load(path.join(img_folder, ELEMENTS_IMG))

        # Define sounds
        # 1st audio (Tinh ngu di em oi)
        self.audio1_file = path.join(snd_folder, (AUDIO1 + AUDIO_FORMAT))
        self.audio1 = pg.mixer.Sound(self.audio1_file)

        #2nd audio (Vine boom)
        self.audio2_file = path.join(snd_folder, (AUDIO2 + AUDIO_FORMAT))
        self.audio2 = pg.mixer.Sound(self.audio2_file)

        #3rd audio (yamate)
        self.audio3_file = path.join(snd_folder, (AUDIO3 + AUDIO_FORMAT))
        self.audio3 = pg.mixer.Sound(self.audio3_file)

        #4th audio (yamate)
        self.audio4_file = path.join(snd_folder, (AUDIO4 + AUDIO_FORMAT))
        self.audio4 = pg.mixer.Sound(self.audio4_file)

        #5th audio (yamate)
        self.audio5_file = path.join(snd_folder, (AUDIO5 + AUDIO_FORMAT))
        self.audio5 = pg.mixer.Sound(self.audio5_file)

        #6th audio (siuuu)
        self.audio6_file = path.join(snd_folder, (AUDIO6 + AUDIO_FORMAT))
        self.audio6 = pg.mixer.Sound(self.audio6_file)

        #7th audio (ai-o-si-ma)
        self.audio7_file = path.join(snd_folder, (AUDIO7 + AUDIO_FORMAT))
        self.audio7 = pg.mixer.Sound(self.audio7_file)

        #8th audio (ngu)
        self.audio8_file = path.join(snd_folder, (AUDIO8+ AUDIO_FORMAT_2))
        self.audio8 = pg.mixer.Sound(self.audio8_file)

        #9th audio (an3tocom)
        self.audio9_file = path.join(snd_folder, (AUDIO9+ AUDIO_FORMAT))
        self.audio9 = pg.mixer.Sound(self.audio9_file)

        # Define sf
        self.audio1_sf = sf.SoundFile(self.audio1_file) # Audio 1 sf
        self.audio2_sf = sf.SoundFile(self.audio2_file) # Audio 2 sf
        self.audio3_sf = sf.SoundFile(self.audio3_file) # Audio 3 sf
        self.audio4_sf = sf.SoundFile(self.audio4_file) # Audio 4 sf
        self.audio5_sf = sf.SoundFile(self.audio5_file) # Audio 5 sf
        self.audio6_sf = sf.SoundFile(self.audio6_file) # Audio 6 sf
        self.audio7_sf = sf.SoundFile(self.audio7_file) # Audio 7 sf
        self.audio8_sf = sf.SoundFile(self.audio8_file) # Audio 8 sf
        self.audio9_sf = sf.SoundFile(self.audio9_file) # Audio 9 sf

        # Load images
        self.moyai = pg.image.load(path.join(img_folder, MOYAI_IMG)) # Moyai 🗿
        self.siuuu = pg.image.load(path.join(img_folder, SIUUU_IMG)) # Siuuu ⚽

    def new(self): 
        self.all_sprites = pg.sprite.Group()
        # Load sprites
        self.audio1_sprite = Audio(self, self.elements_img, (35 + (self.elements_pixels_x / 2)), (12 + (self.elements_pixels_y / 2)))  # Audio 1 sprite
        self.audio2_sprite = Audio(self, self.elements_img, self.audio1_sprite.rect.centerx + self.elements_pixels_x + 24, self.audio1_sprite.rect.centery)  # Audio 2 sprite
        self.audio3_sprite = Audio(self, self.elements_img, self.audio2_sprite.rect.centerx + self.elements_pixels_x + 24, self.audio2_sprite.rect.centery)  # Audio 3 sprite
        self.audio4_sprite = Audio(self, self.elements_img, self.audio1_sprite.rect.centerx, self.audio1_sprite.rect.centery + self.elements_pixels_y + 16)  # Audio 4 sprite
        self.audio5_sprite = Audio(self, self.elements_img, self.audio1_sprite.rect.centerx + self.elements_pixels_x + 24, self.audio4_sprite.rect.centery)  # Audio 5 sprite
        self.audio6_sprite = Audio(self, self.elements_img, self.audio2_sprite.rect.centerx + self.elements_pixels_x + 24, self.audio5_sprite.rect.centery)  # Audio 6 sprite
        self.audio7_sprite = Audio(self, self.elements_img, self.audio4_sprite.rect.centerx, self.audio4_sprite.rect.centery + self.elements_pixels_y + 16)  # Audio 7 sprite
        self.audio8_sprite = Audio(self, self.elements_img, self.audio7_sprite.rect.centerx + self.elements_pixels_x + 24, self.audio7_sprite.rect.centery)  # Audio 8 sprite
        self.audio9_sprite = Audio(self, self.elements_img, self.audio8_sprite.rect.centerx + self.elements_pixels_x + 24, self.audio7_sprite.rect.centery)  # Audio 9 sprite

        # Load texts
        #1st audio (Tinh ngu di em oi)
        self.audio1_text = self.font.render("Tỉnh ngủ đi em ơi", True, TEXT_COLOR)
        self.audio1_text_rect = self.audio1_text.get_rect(center=(self.audio1_sprite.rect.center))

        #2nd audio (Vine boom)
        self.audio2_text = self.font.render("Vine boom", True, TEXT_COLOR)
        self.audio2_text_rect = self.audio2_text.get_rect(center=(self.audio2_sprite.rect.center))

        #3rd audio (yamate)
        self.audio3_text = self.font.render("Yamate Kudasai", True, TEXT_COLOR)
        self.audio3_text_rect = self.audio3_text.get_rect(center=(self.audio3_sprite.rect.center))

        #4th audio (yamate)
        self.audio4_text = self.font.render("Monkey", True, TEXT_COLOR)
        self.audio4_text_rect = self.audio4_text.get_rect(center=(self.audio4_sprite.rect.center))

        #5th audio (OMG)
        self.audio5_text = self.font.render("Oh my god", True, TEXT_COLOR)
        self.audio5_text_rect = self.audio5_text.get_rect(center=(self.audio5_sprite.rect.center))

        #6th audio (siuuu)
        self.audio6_text = self.font.render("SIUUU", True, TEXT_COLOR)
        self.audio6_text_rect = self.audio6_text.get_rect(center=(self.audio6_sprite.rect.center))

        #7th audio (ai-o-si-ma)
        self.audio7_text = self.font.render("Ai O Si Ma", True, TEXT_COLOR)
        self.audio7_text_rect = self.audio7_text.get_rect(center=(self.audio7_sprite.rect.center))

        #8th audio (ngu)
        self.audio8_text = self.font.render("Đồ Ngu", True, TEXT_COLOR)
        self.audio8_text_rect = self.audio8_text.get_rect(center=(self.audio8_sprite.rect.center))

        #9th audio (an3tocom)
        self.audio9_text = self.font.render("noi cai jz", True, TEXT_COLOR)
        self.audio9_text_rect = self.audio9_text.get_rect(center=(self.audio9_sprite.rect.center))

    def run(self):
        while True:
            self.update()
            self.events()
            self.draw()

    def update(self):
        pass
        self.audio1_sprite.update()
        self.audio2_sprite.update()
        self.audio3_sprite.update()
        self.audio4_sprite.update()
        self.audio5_sprite.update()
        self.audio6_sprite.update()
        self.audio7_sprite.update()
        self.audio8_sprite.update()
        self.audio9_sprite.update()

        self.audio1_text_rect = self.audio1_text.get_rect(center=(self.audio1_sprite.rect.center))
        self.audio2_text_rect = self.audio2_text.get_rect(center=(self.audio2_sprite.rect.center))
        self.audio3_text_rect = self.audio3_text.get_rect(center=(self.audio3_sprite.rect.center))
        self.audio4_text_rect = self.audio4_text.get_rect(center=(self.audio4_sprite.rect.center))
        self.audio5_text_rect = self.audio5_text.get_rect(center=(self.audio5_sprite.rect.center))
        self.audio6_text_rect = self.audio6_text.get_rect(center=(self.audio6_sprite.rect.center))
        self.audio7_text_rect = self.audio7_text.get_rect(center=(self.audio7_sprite.rect.center))
        self.audio8_text_rect = self.audio8_text.get_rect(center=(self.audio8_sprite.rect.center))
        self.audio9_text_rect = self.audio9_text.get_rect(center=(self.audio9_sprite.rect.center))

    def draw(self):
        self.screen.fill(BG) # Fill screen with BG color
        # Draw sprites & texts
        self.audio1_sprite.draw(self.screen)
        self.audio2_sprite.draw(self.screen)
        self.audio3_sprite.draw(self.screen)
        self.audio4_sprite.draw(self.screen)
        self.audio5_sprite.draw(self.screen)
        self.audio6_sprite.draw(self.screen)
        self.audio7_sprite.draw(self.screen)
        self.audio8_sprite.draw(self.screen)
        self.audio9_sprite.draw(self.screen)

        self.screen.blit(self.audio1_text, self.audio1_text_rect)
        self.screen.blit(self.audio2_text, self.audio2_text_rect)
        self.screen.blit(self.audio3_text, self.audio3_text_rect)
        self.screen.blit(self.audio4_text, self.audio4_text_rect)
        self.screen.blit(self.audio5_text, self.audio5_text_rect)
        self.screen.blit(self.audio6_text, self.audio6_text_rect)
        self.screen.blit(self.audio7_text, self.audio7_text_rect)
        self.screen.blit(self.audio8_text, self.audio8_text_rect)
        self.screen.blit(self.audio9_text, self.audio9_text_rect)
        
        self.screen.blit(self.moyai, (self.audio2_sprite.rect.left + 12, self.audio2_sprite.rect.centery - 13))
        self.screen.blit(self.siuuu, (self.audio6_sprite.rect.left + 12, self.audio6_sprite.rect.centery - 13))

        pg.display.flip()

    def events(self): # Handle events
        RESET_SOUND_PLAYING = pg.USEREVENT + 1
        for event in pg.event.get():
            if event.type == pg.QUIT:
                sys.exit()
            if event.type == RESET_SOUND_PLAYING:
                self.sound_playing = False # Set sound playing status to False
            elif event.type == pg.MOUSEBUTTONDOWN and not self.sound_playing:
                mouse_x = pg.mouse.get_pos()[0]
                mouse_y = pg.mouse.get_pos()[1]
                print(str('Mouse clicked at (x, y): ') + str(mouse_x) + ', ' + str(mouse_y))
                if mouse_x >= (self.audio1_sprite.rect.left - 1) and mouse_x <= (self.audio1_sprite.rect.right - 1) and mouse_y > (self.audio1_sprite.rect.top - 1) and mouse_y < (self.audio1_sprite.rect.bottom):
                    self.audio1.play() # Play Audio 1
                    print("Sound played: Tinh ngu di em oi")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio1_sf.frames / self.audio1_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio2_sprite.rect.left - 1) and mouse_x <= (self.audio2_sprite.rect.right - 1) and mouse_y > (self.audio2_sprite.rect.top - 1) and mouse_y < (self.audio2_sprite.rect.bottom):
                    self.audio2.play() # Play Audio 2
                    print("Sound played: Vine boom")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio2_sf.frames / self.audio2_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio3_sprite.rect.left - 1) and mouse_x <= (self.audio3_sprite.rect.right - 1) and mouse_y > (self.audio3_sprite.rect.top - 1) and mouse_y < (self.audio3_sprite.rect.bottom):
                    self.audio3.play() # Play Audio 3
                    print("Sound played: Yamate kudasai")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio3_sf.frames / self.audio3_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio4_sprite.rect.left - 1) and mouse_x <= (self.audio4_sprite.rect.right - 1) and mouse_y > (self.audio4_sprite.rect.top - 1) and mouse_y < (self.audio4_sprite.rect.bottom):
                    self.audio4.play() # Play Audio 4
                    print("Sound played: Monkey")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio4_sf.frames / self.audio4_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio5_sprite.rect.left - 1) and mouse_x <= (self.audio5_sprite.rect.right - 1) and mouse_y > (self.audio5_sprite.rect.top - 1) and mouse_y < (self.audio5_sprite.rect.bottom):
                    self.audio5.play() # Play Audio 5
                    print("Sound played: OMG")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio5_sf.frames / self.audio5_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio6_sprite.rect.left - 1) and mouse_x <= (self.audio6_sprite.rect.right - 1) and mouse_y > (self.audio6_sprite.rect.top - 1) and mouse_y < (self.audio6_sprite.rect.bottom):
                    self.audio6.play() # Play Audio 6
                    print("Sound played: siuuu")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio6_sf.frames / self.audio6_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio7_sprite.rect.left - 1) and mouse_x <= (self.audio7_sprite.rect.right - 1) and mouse_y > (self.audio7_sprite.rect.top - 1) and mouse_y < (self.audio7_sprite.rect.bottom):
                    self.audio7.play() # Play Audio 7
                    print("Sound played: ai-o-si-ma")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio7_sf.frames / self.audio7_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio8_sprite.rect.left - 1) and mouse_x <= (self.audio8_sprite.rect.right - 1) and mouse_y > (self.audio8_sprite.rect.top - 1) and mouse_y < (self.audio8_sprite.rect.bottom):
                    self.audio8.play() # Play Audio 8
                    print("Sound played: ngu")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio8_sf.frames / self.audio8_sf.samplerate)) * 1000)) # Reset sound playing status
                elif mouse_x >= (self.audio9_sprite.rect.left - 1) and mouse_x <= (self.audio9_sprite.rect.right - 1) and mouse_y > (self.audio9_sprite.rect.top - 1) and mouse_y < (self.audio9_sprite.rect.bottom):
                    self.audio9.play() # Play Audio 9
                    print("Sound played: an3tocom")
                    self.sound_playing = True # Set sound playing status to True
                    pg.time.set_timer(RESET_SOUND_PLAYING, int(float(format(self.audio9_sf.frames / self.audio9_sf.samplerate)) * 1000)) # Reset sound playing status

a = App()
while True:
    a.load_data()
    a.new()
    a.run()