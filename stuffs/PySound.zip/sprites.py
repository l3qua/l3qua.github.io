import pygame as pg
from settings import *

class Audio(pg.sprite.Sprite):
    def __init__(self, app, image, x, y):
        self.groups = app.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.app = app
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)     

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def update(self):
        keys = pg.key.get_pressed()
        if keys[pg.K_UP]:
            self.rect.y -= 1
        elif keys[pg.K_DOWN]:
            self.rect.y += 1