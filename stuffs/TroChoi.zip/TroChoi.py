import pgzrun
import time
import sys
from random import randint

TITLE = "(Màn hình chính) Trò Chơi Trắc Nghiệm"
WIDTH = 800
HEIGHT = 600

tof = False
nextex = None
ansed_list = []
show_ans = False
score = 0
ans = 0
ex = 0
first_time = True
clicked = 0
game_complete = False
ex1 = "Sai"
ex2 = "Sai"
ex3 = "Sai"
ex4 = "Sai"
ex5 = "Sai"
ex6 = "Sai"
ex7 = "Sai"
ex8 = "Sai"
ex9 = "Sai"
ex10 = "Sai"
ex11 = "Sai"
ex12 = "Sai"
ex13 = "Sai"
ex14 = "Sai"
ex15 = "Sai"
ex16 = "Sai"
ex17 = "Sai"
ex18 = "Sai"
ex19 = "Sai"
ex20 = "Sai"
line1_x = 10
line2_x = (line1_x + 100)

ans1 = Actor("ans")
ans1.pos = (-100, -100)
ans2 = Actor("ans")
ans2.pos = (-100, -100)
ans3 = Actor("ans")
ans3.pos = (-100, -100)
ans4 = Actor("aaa")
ans4.pos = (550, 245)
ans5 = Actor("aaa")
ans5.pos = (100, -100)
ans6 = Actor("aaa")   
ans6.pos = (100, -100)
ansA = Actor("ans2")   
ansA.pos = (100, -100)
ansB = Actor("ans2")   
ansB.pos = (100, -100)
ansC = Actor("ans2")   
ansC.pos = (100, -100)
ansD = Actor("ans2")   
ansD.pos = (100, -100)

def draw():
    global first_time, ans, ex, ex1, ex2, ex3, ex4, ex5, ex6, ex7, ex8, ex9, ex10, show_ans, line1_x, line2_x, ex11, ex12, ex13, ex14, ex15, ex16, ex17, ex18, ex19, ex20
    screen.clear()
    screen.blit('bg',(0, 0))
    if first_time:
        ans4.draw()
        screen.draw.text("Luật chơi và cách chơi:", (20, 10), fontname="icielcadena", fontsize = 30)
        screen.draw.text("Khi hiện ra các đáp án, hãy click vào đáp án mà bạn cho là", (20, 60), fontname="icielcadena", fontsize = 30)
        screen.draw.text("  đúng để chọn đáp án đó", (20, 95), fontname="icielcadena", fontsize = 30)
        screen.draw.text("Khi đã chọn sau 1s sẽ hiện ra đáp án đúng.", (20, 140), fontname="icielcadena", fontsize=30)
        screen.draw.text("Click vào ô 'Tôi đã hiểu' để bắt đầu", (20, 220), fontname="icielcadena", fontsize = 30)
        screen.draw.text("Nếu phát hiện các hành vi gian lận, trò chơi sẽ thoát", (20, 180), fontname="icielcadena", fontsize=30)
        screen.draw.text("Chúng tôi khuyên bạn nên đọc hdsd trong ổ đĩa chương trình để hiểu thêm", (20, 265), fontname="icielcadena", fontsize=20)
        screen.draw.text("Tôi đã hiểu", center=(ans4.pos), fontname="anton", fontsize = 25, color="white")
    elif not game_complete and not first_time:
        ans1.draw()
        ans2.draw()
        ans3.draw()
        ansA.draw()
        ansB.draw()
        ansC.draw()
        ansD.draw()
        screen.draw.text("1", center=(ans1.pos), fontname="anton", fontsize = 60, color="black")
        screen.draw.text("2", center=(ans2.pos), fontname="anton", fontsize = 60, color="black")
        screen.draw.text("3", center=(ans3.pos), fontname="anton", fontsize = 60, color="black")
        screen.draw.text("1", center=(ansA.pos), fontname="anton", fontsize = 60, color="black")
        screen.draw.text("2", center=(ansB.pos), fontname="anton", fontsize = 60, color="black")
        screen.draw.text("3", center=(ansC.pos), fontname="anton", fontsize = 60, color="black")
        screen.draw.text("4", center=(ansD.pos), fontname="anton", fontsize = 60, color="black")
        if ex == 1:
            screen.draw.text("A. Nhiên liệu hạt nhân là chất gì?", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Chất phóng xạ tạo ra nhiệt, rất an toàn", (20, 60), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Chất phóng xạ tạo ra nhiệt, không an toàn", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Không có đáp án đúng.", (20, 140), fontname="icielcadena", fontsize = 30)
        if ex == 2:
            screen.draw.text("B. Cây xanh tạo ra chất hữu cơ từ các nguyên liệu ...", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Nước, muối khoáng, chất điệp lục", (20, 60), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Khí cacbônic, ánh sáng, diệp lục", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Nước, muối khoáng, cacbônic, ánh sáng, diệp lục", (20, 140), fontname="icielcadena", fontsize = 30)
        if ex == 3:
            screen.draw.text("C. Công thức quy đổi từ khối lượng (g) sang Newton", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. N = (10 : (1000 x khối lượng (g)))", (20, 60), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. N = (10 x (1000 x khối lượng (g)))", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. N = (10 : (khối lượng (g) : 1000))", (20, 140), fontname="icielcadena", fontsize = 30)
        if ex == 4:
            screen.draw.text("D. Tại sao người ta khi nấu canh thường bỏ muối", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("  vào trước sau đó mới cho rau vào?", (10, 50), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Vì nhiệt độ sôi của nước muối thường cao hơn nên khiến", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("  rau dễ chín hơn", (20, 135), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Vì nhiệt độ sôi cao khiến rau dễ chín hơn và giữ lại chất", (20, 180), fontname="icielcadena", fontsize = 30)
            screen.draw.text("  dinh dưỡng", (20, 215), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Tất cả các đáp án trên đều đúng.", (20, 260), fontname="icielcadena", fontsize = 30)
        if ex == 5:
            screen.draw.text("E. Nhóm nào thuộc cây lâu năm?", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Dừa, bưởi, mít, thị, ổi", (20, 60), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Lúa, ngô, khoai, nhãn", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Sắn, cỏ, hoa hồng, hoa đào", (20, 140), fontname="icielcadena", fontsize = 30)
        if ex == 6:
            screen.draw.text("F. Ai là người phát minh ra thang nhiệt độ được sử", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("  dụng phổ biến ở Việt Nam?", (10, 50), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Anders Celsius (1701 - 1744)", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. William Thomson (1824 - 1907)", (20, 140), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Daniel Gabriel Fahrenheit (1686 - 1736)", (20, 180), fontname="icielcadena", fontsize = 30)
        if ex == 7:
            screen.draw.text("G. Nguyên nhân gây ra ô nhiễm không khí?", (10,10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Cháy rừng, núi lửa, nhà máy nhiệt điện", (20, 60), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Phương tiện giao thông lỗi thời, đốt rơm rạ", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Tất cả các đáp án trên đều đúng", (20, 140), fontname="icielcadena", fontsize = 30)
        if ex == 8:
            screen.draw.text("H. Chúng ta có thể làm gì để vật kim loại không bị gỉ?", (10, 10), fontname="icielcadena", fontsize = 33)
            screen.draw.text("1. Tránh tiếp xúc với các chất gây ăn mòn", (20, 60), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Phủ một lớp sơn lên vật liệu kim loại", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Tất cả các đáp án trên đều đúng", (20, 140), fontname="icielcadena", fontsize = 30)
        if ex == 9:
            screen.draw.text("I. Tại sao các ao nuôi tôm thường lắp hệ thống ", (10,10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("  quạt nước?", (10, 50), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Vì oxygen tan nhiều trong nước nên cần quạt gió để loại", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("  bỏ bớt oxygen ra ngoài", (20, 135), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. Vì oxygen tan ít trong nước nên cần phải dùng quạt gió",(20, 180), fontname="icielcadena", fontsize = 30)
            screen.draw.text("  để tăng lượng oxygen cho tôm sống", (20, 215), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Tất cả các đáp án trên đều sai", (20, 260), fontname="icielcadena", fontsize = 30)
        if ex == 10:
            screen.draw.text("J. Một xe máy có trọng lượng 2100 N vậy khối lượng", (10, 10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("  của chiếc xe máy là?", (10, 50), fontname="icielcadena", fontsize=35)
            screen.draw.text("1. 2100 (N) : 10 = 210 kg", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("2. 2100 (N) x 10 = 21000 kg", (20, 140), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. 2100 (N) : 10 = 210 g", (20, 180), fontname="icielcadena", fontsize = 30)
        if ex == 11:
            screen.draw.text("K. Tính chất nào sau đây mà oxygen không có?", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Oxygen là chất khí", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Không màu, không mùi, không vị", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Nặng hơn không khí", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Tan nhiều trong nước", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 12:
            screen.draw.text("L. Lực đàn hồi có đặc điểm:", (10,10), fontname="icielcadena", fontsize = 35)
            screen.draw.text("1. Không phụ thuộc vào độ biến dạng", (20, 60), fontname="icielcadena", fontsize=30)
            screen.draw.text("2. Độ biến dạng tăng thì lực đàn hồi giảm", (20, 100), fontname="icielcadena", fontsize = 30)
            screen.draw.text("3. Độ biến dạng tăng thì lực đàn hồi tăng", (20, 140), fontname="icielcadena", fontsize = 30)
            screen.draw.text("4. Phụ thuộc vào môi trường bên ngoài", (20, 180), fontname="icielcadena", fontsize=30)
        if ex == 13:
            screen.draw.text("M. Thực vật chia làm mấy nhóm chính?", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Cây có hoa và cây một năm", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Cây một năm và cây lâu năm", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Cây không hoa và cây lâu năm", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Cây có hoa và không có hoa", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 14:
            screen.draw.text("N. Cách sử dụng cao su an toàn, hiệu quả?", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Để nơi có nhiệt độ quá cao", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Tẩy giặt bằng xà phòng, xăng dầu", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Không để hóa chất dính vào", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Sơn phủ bề mặt, bôi dầu mỡ", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 15:
            screen.draw.text("O. Nhóm nào sau đây là chất tinh khiết?", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Nước Khoáng, nước biển", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Sodium chloride, sacaroza", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Nước đóng chai, nước ngọt", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Tất cả các ý trên đều sai", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 16:
            screen.draw.text("P. Nhóm cây nào gồm toàn thực vật có hoa?", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Cây vải, hồng xiên, na, đậu, dừa", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Cây cầu, táo, thông, lúa, vạn thiên thanh", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Cây rau bợ, chuối, xà cừ, phượng", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Tất cả các đáp án trên đều đúng", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 17:
            screen.draw.text("Q. Đơn vị đo khối lượng là", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Ki-lô-gam (kg)", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Mét (m)", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Cen-ti-mét (cm)", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Niu-ton (N)", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 18:
            screen.draw.text("R. Cơ thể thực vật gồm những cơ quan nào?", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Cơ quan rễ và thân", (20, 60), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Cơ quan sinh sản và hoa, quả, hạt", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Cơ quan sinh dưỡng, rể, thân, lá", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Cơ quan sinh dưỡng và sinh sản", (20, 180), fontname = "icielcadena", fontsize = 30)
        if ex == 19:
            screen.draw.text("S. Trong tự nhiên sinh vật được chia thành các", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("  nhóm như thế nào? ", (10,50), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Thực vật, động vật, nấm và vi khuẩn", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Thực vật, động vật, nấm và vi sinh vật", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Thực vật, động vật và vi sinh vật", (20, 180), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Thực vật và động vật", (20, 220), fontname = "icielcadena", fontsize = 30)
        if ex == 20:
            screen.draw.text("T. Trước khi đó chiều dài của vật người ta thường ", (10,10), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("  ước lượng chiều dài của vật để?", (10,50), fontname = "icielcadena", fontsize = 35)
            screen.draw.text("1. Đặt mắt đúng cách", (20, 100), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("2. Đọc kết quả đo chính xác", (20, 140), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("3. Lựa chọn thước đo phù hợp", (20, 180), fontname = "icielcadena", fontsize = 30)
            screen.draw.text("4. Đặt vật đo đúng cách", (20, 220), fontname = "icielcadena", fontsize = 30)

        if show_ans and ex == 5 or show_ans and ex == 6 or show_ans and ex == 10 or show_ans and ex == 16 or show_ans and ex == 17 or show_ans and ex == 19: # 1 correct
            screen.draw.text("Đáp án đúng là đáp án số 1.", center=(400, 455), fontname="icielcadena", fontsize=30, color="black")
        elif show_ans and ex == 1 or show_ans and ex == 3 or show_ans and ex == 9 or show_ans and ex == 15: # 2 correct
            screen.draw.text("Đáp án đúng là đáp án số 2.", center=(400, 455), fontname="icielcadena", fontsize=30, color="black")
        elif show_ans and ex == 2 or show_ans and ex == 4 or show_ans and ex == 7 or show_ans and ex == 8 or show_ans and ex == 12 or show_ans and ex == 14 or show_ans and ex == 20: # 3 correct
            screen.draw.text("Đáp án đúng là đáp án số 3.", center=(400, 455), fontname="icielcadena", fontsize=30, color="black")
        elif show_ans and ex == 11 or show_ans and ex == 13 or show_ans and ex == 18: #4 correct
            screen.draw.text("Đáp án đúng là đáp án số 4.", center=(400, 455), fontname="icielcadena", fontsize=30, color="black")

    elif game_complete:
        ans5.draw()
        ans6.draw()
        screen.draw.text("Ban da hoan thanh tro choi  ", (120,((HEIGHT/2)-250)), fontname = "icielcadena", fontsize = 45)
        screen.draw.text(("voi tong so diem la:"), (120,((HEIGHT/2)-200)), fontname = "icielcadena", fontsize = 45)
        screen.draw.text(str(score), (520,((HEIGHT/2)-200)), fontname="icielcadena", fontsize = 45)
        screen.draw.text("Danh sach cac cau dung/sai", center=(((WIDTH/2)-90), ((HEIGHT/2)-60)), fontname="icielcadena", fontsize=40, color = "black")
        screen.draw.text("Cau A:", (line1_x, (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex1), (line2_x, (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau B:", (line1_x, (HEIGHT/2)), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex2), (line2_x, (HEIGHT/2)), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau C:", (line1_x, (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex3), (line2_x, (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau D:", (line1_x, (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex4), (line2_x, (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau E:", (line1_x, (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex5), (line2_x, (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau F:", ((line1_x+200), (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex6), ((line2_x+200), (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau G:", ((line1_x+200), (HEIGHT/2)+0), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex7), ((line2_x+200), (HEIGHT/2)+0), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau H:", ((line1_x+200), (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex8), ((line2_x+200), (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau I:", ((line1_x+200), (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex9), ((line2_x+200), (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau J:", ((line1_x+200), (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex10), ((line2_x+200), (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau K:", (line1_x+200*2, (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex11), (line2_x+200*2, (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau L:", (line1_x+200*2, (HEIGHT/2)), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex12), (line2_x+200*2, (HEIGHT/2)), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau M:", (line1_x+200*2, (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex13), ((line2_x+200*2)+8, (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau N:", (line1_x+200*2, (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex14), (line2_x+200*2, (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau O:", (line1_x+200*2, (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex15), (line2_x+200*2, (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau P:", ((line1_x+200*3), (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex16), ((line2_x+200*3), (HEIGHT/2)-40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau Q:", ((line1_x+200*3), (HEIGHT/2)+0), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex17), ((line2_x+200*3), (HEIGHT/2)+0), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau R:", ((line1_x+200*3), (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex18), ((line2_x+200*3), (HEIGHT/2)+40), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau S:", ((line1_x+200*3), (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex19), ((line2_x+200*3), (HEIGHT/2)+80), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Cau T:", ((line1_x+200*3), (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text(str(ex20), ((line2_x+200*3), (HEIGHT/2)+120), fontname="icielcadena", fontsize = 35, color="black")
        screen.draw.text("Choi lai", center=(ans5.pos), fontname="icielcadena", fontsize = 30, color = "white")
        screen.draw.text("Thoat", center=(ans6.pos), fontname="icielcadena", fontsize = 30, color = "white")

def on_mouse_down(pos):
    global Score, ans, game_complete, first_time, ex, clicked, ex, ex1, ex2, ex3, ex4, ex5, ex6, ex7, ex8, ex9, ex10, show_ans, ansA, ansB, ansC, ansD
    x, y = pos
    if not game_complete:
        if ans4.collidepoint(pos):
            first_time = False
            ex = ex + 1
        if ans3.collidepoint(pos):
            ans = 3
            clicked = clicked + 1
            if clicked == 1:
                check_ans()
        if ans2.collidepoint(pos):
            ans = 2
            clicked = clicked + 1
            if clicked == 1:
                check_ans()
        if ans1.collidepoint(pos):
            ans = 1
            clicked = clicked + 1
            if clicked == 1:    
                check_ans()
        if ansA.collidepoint(pos):
            ans = "A"
            clicked = clicked = 1
            if clicked == 1:
                check_ans()
        if ansB.collidepoint(pos):
            ans = "B"
            clicked = clicked + 1
            if clicked == 1:
                check_ans()
        if ansC.collidepoint(pos):
            ans = "C"
            clicked = clicked + 1
            if clicked == 1:
                check_ans()
        if ansD.collidepoint(pos):
            ans = "D"
            clicked = clicked + 1
            if clicked == 1:    
                check_ans()
    if game_complete:
        if ans6.collidepoint(pos):
            sys.exit()
        if ans5.collidepoint(pos):
            replay()

def check_ans():
    global ans, score, ex, ex1, ex2, ex3, ex4, ex5, ex6, ex7, ex8, ex9, ex10, ex11, ex12, ex13, ex14, ex15, ex16, ex17, ex18, ex19, ex20, tof
    if ex == 5 or ex == 6 or ex == 10: # 1 correct
        if ans == 1:
            ans1.image = "ans-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
        if ans == 2:
            ans2.image = "ans-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == 3:
            ans3.image = "ans-y"
            tof = False
            clock.schedule(show_true_ans, 1)
    elif ex == 1 or ex == 3 or ex == 9: # 2 correct
        if ans == 1:
            tof = False
            ans1.image = "ans-y"
            clock.schedule(show_true_ans, 1)
        if ans == 2:
            ans2.image = "ans-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
        if ans == 3:
            tof = False
            ans3.image = "ans-y"
            clock.schedule(show_true_ans, 1)
    elif ex == 2 or ex == 4 or ex == 7 or ex == 8: # 3 correct
        if ans == 1:
            tof = False
            ans1.image = "ans-y"
            clock.schedule(show_true_ans, 1)
        if ans == 2:
            tof = False
            ans2.image = "ans-y"
            clock.schedule(show_true_ans, 1)
        if ans == 3:
            ans3.image = "ans-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
    elif ex == 11 or ex == 13 or ex == 18: # 4 correct
        if ans == "A":
            ansA.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "B":
            ansB.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "D":
            ansD.image = "ans2-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
        if ans == "C":
            ansC.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
    elif ex == 12 or ex == 14 or ex == 20: #3 correct
        if ans == "A":
            ansA.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "B":
            ansB.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "C":
            ansC.image = "ans2-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
        if ans == "D":
            ansD.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
    elif ex == 15: #2 correct
        if ans == "A":
            ansA.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "C":
            ansC.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "B":
            ansB.image = "ans2-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
        if ans == "D":
            ansD.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
    elif ex == 16 or ex == 17 or ex == 19: #1 correct
        if ans == "B":
            ansB.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "C":
            ansC.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
        if ans == "A":
            ansA.image = "ans2-y"
            score = score + 0.5
            tof = True
            clock.schedule(show_true_ans, 1)
        if ans == "D":
            ansD.image = "ans2-y"
            tof = False
            clock.schedule(show_true_ans, 1)
    if ex == 1:
        if tof:
            ex1 = "Dung"
    if ex == 2:
        if tof :
            ex2 = "Dung"
    if ex == 3:
        if tof :
            ex3 = "Dung"
    if ex == 4:
        if tof :
            ex4 = "Dung"
    if ex == 5:
        if tof :
            ex5 = "Dung"
    if ex == 6:
        if tof :
            ex6 = "Dung"
    if ex == 7:
        if tof :
            ex7 = "Dung"
    if ex == 8:
        if tof :
            ex8 = "Dung"
    if ex == 9:
        if tof :
            ex9 = "Dung"
    if ex == 10:
        if tof :
            ex10 = "Dung"
    if ex == 11:
        if tof :
            ex11 = "Dung"
    if ex == 12:
        if tof :
            ex12 = "Dung"
    if ex == 13:
        if tof :
            ex13 = "Dung"
    if ex == 14:
        if tof:
            ex14 = "Dung"
    if ex == 15:
        if tof:
            ex15 = "Dung"
    if ex == 16:
        if tof:
            ex16 = "Dung"
    if ex == 17:
        if tof:
            ex17 = "Dung"
    if ex == 18:
        if tof:
            ex18 = "Dung"
    if ex == 19:
        if tof:
            ex19 = "Dung"
    if ex == 20:
        if tof:
            ex20 = "Dung"

def replay():
    global ans, score, ex, ex1, ex2, ex3, ex4, ex5, ex6, ex7, ex8, ex9, ex10, game_complete
    score = 0
    ex = 1
    ex1 = "Sai"
    ex2 = "Sai"
    ex3 = "Sai"
    ex4 = "Sai"
    ex5 = "Sai"
    ex6 = "Sai"
    ex7 = "Sai"
    ex8 = "Sai"
    ex9 = "Sai"
    ex10 = "Sai"
    game_complete = False
    reset_ans()

def show_true_ans():
    global ex, show_ans
    if ex == 5 or ex == 6 or ex == 10: # 1 correct
        if ans == 1:
            ans1.image = "ans-g"
            sounds.true.play()
            show_ans = True     
            clock.schedule(reset_ans, 2)
        if ans == 2:
            ans2.image = "ans-r"
            ans1.image = "ans-g"
            sounds.false.play()
            show_ans = True     
            clock.schedule(reset_ans, 2)
        if ans == 3:
            ans3.image = "ans-r"
            ans1.image = "ans-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
    if ex == 1 or ex == 3 or ex == 9: # 2 correct
        if ans == 1:
            ans1.image = "ans-r"
            ans2.image = "ans-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
        if ans == 2:
            ans2.image = "ans-g"
            show_ans = True
            sounds.true.play()     
            clock.schedule(reset_ans, 2)
        if ans == 3:
            ans3.image = "ans-r"
            ans2.image = "ans-g"
            sounds.false.play()
            show_ans = True     
            clock.schedule(reset_ans, 2)
    if ex == 2 or ex == 4 or ex == 7 or ex == 8: # 3 correct
        if ans == 2:
            ans2.image = "ans-r"
            ans3.image = "ans-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
        if ans == 3:
            ans3.image = "ans-g"
            sounds.true.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
        if ans == 1:
            ans1.image = "ans-r"
            ans3.image = "ans-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
    if ex == 16 or ex == 17 or ex == 19: # A correct
        if ans == "B":
            ansB.image = "ans2-r"
            ansA.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "C":
            ansC.image = "ans2-r"
            ansA.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "D":
            ansD.image = "ans2-r"
            ansA.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "A":
            ansA.image = "ans2-g"
            sounds.true.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
    if ex == 15: # B correct
        if ans == "A":
            ansA.image = "ans2-r"
            ansB.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "C":
            ansC.image = "ans2-r"
            ansB.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "D":
            ansD.image = "ans2-r"
            ansB.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "B":
            ansB.image = "ans2-g"
            sounds.true.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
    if ex == 12 or ex == 14 or ex == 20: # C correct
        if ans == "A":
            ansA.image = "ans2-r"
            ansC.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "B":
            ansB.image = "ans2-r"
            ansC.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "D":
            ansD.image = "ans2-r"
            ansC.image = "ans2-g"
            sounds.false.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
        if ans == "C":
            ansC.image = "ans2-g"
            sounds.true.play()
            show_ans = True
            clock.schedule(reset_ans, 2)
    if ex == 11 or ex == 13 or ex == 18: # D correct
        if ans == "A":
            ansA.image = "ans2-r"
            ansD.image = "ans2-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
        if ans == "D":
            ansD.image = "ans2-g"
            sounds.true.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
        if ans == "B":
            ansB.image = "ans2-r"
            ansD.image = "ans2-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
        if ans == "C":
            ansC.image = "ans2-r"
            ansD.image = "ans2-g"
            sounds.false.play()
            show_ans = True 
            clock.schedule(reset_ans, 2)
            
def reset_ans():
    global score, ans, ex, game_complete, clicked, show_ans, ansed_list, nextex
    ans = 0
    show_ans = False
    ans1.image = "ans"
    ans2.image = "ans"
    ans3.image = "ans"
    ansA.image = "ans2"
    ansB.image = "ans2"
    ansC.image = "ans2"
    ansD.image = "ans2"
    ansed_list.append(ans)
    ex = ex + 1
    clicked = 0
    if ex > 20:
        sounds.completed.play()

def update():
    global first_time, TITLE, ex, score, clicked, game_complete, ans1, ans2, ans3, show_ans, ans
    if not first_time and not game_complete and ex <= 10:
        ans1.pos = (153, 535)
        ans2.pos = (400, 535)
        ans3.pos = (647, 535)
        ans4.pos = (-100, -100)
        ansA.pos = (-100, -100)
        ansB.pos = (-100, -100)
        ansC.pos = (-100, -100)
        ansD.pos = (-100, -100)
        TITLE = "(Đang chơi) Trò Chơi Trắc Nghiệm"
    if not first_time and not game_complete and ex >= 11:
        ans1.pos = (-100, -100)
        ans2.pos = (-100, -100)
        ans3.pos = (-100, -100)
        ans4.pos = (-100, -100)
        ansA.pos = (100, 535)
        ansB.pos = (300, 535)
        ansC.pos = (500, 535)
        ansD.pos = (700, 535)
        TITLE = "(Đang chơi) Trò Chơi Trắc Nghiệm"
    if game_complete and not first_time:
        ans1.pos = (-100, -100)
        ans2.pos = (-100, -100)
        ans3.pos = (-100, -100)
        ans4.pos = (-100, -100)
        ans5.pos = (300,550)
        ans6.pos = (500,550)
    if score > ex:
        sys.exit()
    if ex > 20:
        TITLE = "(Đã hoàn thành) Trò Chơi Trắc Nghiệm"
        game_complete = True

pgzrun.go()