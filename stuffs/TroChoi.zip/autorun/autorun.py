import pgzrun
import time
import sys
from random import randint

TITLE = "Tro Choi Trac Nghiem - Intro"
WIDTH = 800
HEIGHT = 600

gamename_x = 540
gamename_y = 10

playbutton = Actor('play')
playbutton.pos = (((380-45)+20, 215+20))

def draw():
    screen.clear()
    screen.blit('bg',(0, 0))
    screen.draw.text("Chào mừng bạn đã đến với:", (5, 20), fontname="icielcadena", fontsize = 45)
    screen.blit('icon', (gamename_x+5, gamename_y+5))
    screen.draw.text("TRÒ CHƠI", ((gamename_x+55), (gamename_y)), fontname="anton", fontsize = 40)
    screen.draw.text("TRẮC NGHIỆM", ((gamename_x), (gamename_y+50)), fontname="anton", fontsize = 40)
    screen.draw.text("Chơi Trò Chơi Trắc Nghiệm", (380, 210), fontname = "icielcadena", fontsize = 36)
    screen.blit('line', ((380-45), 260))
    playbutton.draw()

def gn_xp():
    global gamename_x, gamename_y
    for i in range(7):
        gamename_x += 5
    clock.schedule(gn_yp, 1)

def gn_yp():
    global gamename_x, gamename_y
    for i in range(7):
        gamename_y += 5
    clock.schedule(gn_xm, 1)

def gn_xm():
    global gamename_x, gamename_y
    for i in range(7):
        gamename_x -= 5
    clock.schedule(gn_ym, 1)

def gn_ym():
    global gamename_x, gamename_y
    for i in range(7):
        gamename_y -= 5
    clock.schedule(gn_xp, 1)

def on_mouse_down(pos):
    global playbutton
    x, y = pos
    if playbutton.collidepoint(pos):
        open('./TroChoi/TroChoi.py')

clock.schedule(gn_xp, 2)
pgzrun.go()